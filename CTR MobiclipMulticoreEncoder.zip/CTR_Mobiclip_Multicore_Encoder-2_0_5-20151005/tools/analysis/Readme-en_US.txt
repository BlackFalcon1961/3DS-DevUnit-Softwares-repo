Mobiclip Moflex Analysis Tool for CTR
=====================================

Date of release: 12/18/2014

About this tool
---------------
This tool enables the user to :
+ Play a moflex file on CTR
+ Analyze a moflex file on CTR. Analysis will produce a graph showing the decompression time (microseconds per frame) on CTR, after compression


+ The Mobiclip Moflex Analysis Tool runs on a PC connected with a CTR-Debugger
+ It is intended to be used for playing and analyzing a moflex file on CTR (cci will automatically loaded to debugger)
+ Analysis displays the decompression time (microseconds) for each frame of the moflex video file


Process to ensure that video will not exceed certain CPU load for decompression
-------------------------------------------------------------------------------
+Encode video using Multicore Encoder
+Analyse the moflex file with Mobiclip Moflex Analysis Tool
+Confirm that decompression time for each frame is under the expected limit
+If that's not the case, re-encode the movie with the Multicore Encoder with different parameters (for example, by lowering the bitrate)
+Analyze again the moflex file

+Repeat this procedure until the decompression time for every frame is under the expected limit


Instructions
------------
+ Turn on your CTR debbugger, if not turned on.
+ On PC, launch the tool with MobiclipMoflexAnalysisTool.exe
+ Drag and drop a moflex file on the tool
+ Choose between "Play on CTR" and "Analyze on CTR"
+ Right-clicking on the tool provides the following options :
  - Set Limit : enables the user to set a limit in microseconds for the decompression time. This limit will be shown as a red line on the graph.
  - Exit Application

  
Requirements
------------
+Mobiclip Moflex Analysis Tool has the following system requirements.
  - A PC that can run the CTR development and debugger tools.
  - .NET 4.0 Runtime (search Microsoft.com for ".net 4.0 runtime" or visit http://www.microsoft.com/en-us/download/details.aspx?id=17851)
+The Mobiclip Moflex Analysis Tool has been confirmed to work with : CTR SDK 10.1.0 firmware 0.23.5


Note
----
+The folder cci contains two files 
  - MobiclipBench.cci
  - MobiclipMulticoreEncoderPlayer3DS.cci
+These files are used by the tool to analyze and playback the video. They should not be runned directly on the CTR debugger.

  
