This readme describes two script files that help to automate encoding jobs for the Mobiclip Multicore Encoder tool.

----------------------------------------------
The script files are written in the Python programming language, and require that the Python interpreter is installed on your PC.

Both scripts require a job queue file as input, which must contain only one job. This job defines how the movie file will be processed.

Queue files (.queue) must be created and saved with the Mobiclip Multicore Encoder tool. Please see the user manual in the documents folder for more information.   

When the scripts run, the input and output filenames and directories that are defined in the queue file are replaced by the arguments passed to the scripts on the commandline.

----------------------------------------------

------------
MME_Encode.py Usage:

Use MME_Encode.py to encode one specific movie file with Mobiclip Multicore Encoder.

This script is useful if want to encode a specific movie file, and you often use the same encoding specifications.
------------

MME_Encode.py [OPTIONS] <queue> <video> <output>

OPTIONS arguments are optional :
 -h, --help : show help message

Positional (required) arguments :
<queue> :  name of the queue file to use to encode your movie file
<video> :  name of the input movie file to be encoded 
<output> : output directory for MoFlex file (will be created if it does not exist)

Examples:
MME_Encode.py Split_Side-by-Side.queue Video_test.mp4 "Output Video"
MME_Encode.py Split_Side-by-Side.queue C:\Work\InputVideo\Video_test.avi "C:\Output Video"

----------------------------------------------

------------
MME_Batch_Multi_File.py usage:

Use MME_Batch_Multi_File.py to encode all the movie files in one directory with the Mobiclip Multicore Encoder tool.

This script scans the input directory for all movie files ending with .MP4, .AVI, .MKV and .MOV, and then encodes them with the job defined in the specified queue file. The same filename is used for the output file, except that the file extension is changed to .MoFlex. 

To save time, if the script detects that a file has already been encoded, it will be skipped. The tool skips a file if a .MoFlex file already exists in the output directory with the same name as the input file, and if the MoFlex file's creation date is later than the source movie file. 

This script is useful if you would like to repeatedly scan an input directory for newly added movie files that need to be encoded. To rescan the directory just relaunch the script, or you might want to schedule the script to be run regularly.
------------
MME_Batch_Multi_File.py [OPTIONS] <queue> <input> <output>

OPTIONS arguments are optional :
 -h, --help : show help message
 -c, --clean : deletes all files in output directory before starting (no input files will be skipped)
 
Positional (required) arguments :
<queue> : queue file to use to encode movies
<input> : input directory containing the movie files to be encoded
<output> : output directory (will be created if does not exist)

Examples :
MME_Batch_Multi_File.py Split_Side-by-Side.queue InputVideo "Output Video"
MME_Batch_Multi_File.py --clean Split_Side-by-Side.queue C:\Work\InputVideo "C:\Output Video"

------------
Notes / Requirements :
* This script is to be run from a Windows command prompt window and has been tested with Python v2.7.4 on Windows 7, which can be downloaded from http://www.python.org/
* The queue file must contain only one job. If multiple encoding profiles are required, then add multiple "Mobiclip Encoder" filters to the graph that defines the job in your queue file.
* The Mobiclip Multicore Encoder tool must not already be running when you launch the script, or you will see an error and nothing will be processed. For this reason, do not attempt to launch multiple instances of the scripts simultaneously. Only one instance of MobiclipMulticoreEncoder.exe can run at a time.
* If there is a space in your directory names or filenames, the complete path must be enclosed in quotes like this : "C:\Output Video"

------------
Troubleshooting :
* First verify that MobiclipMulticoreEncoder.exe is not already running when you launch the script, by checking the Process tab of the Windows Task Manager.

* If no MoFlex files are created in the output directory, then verify the queue file is valid by doing the following :
- Launch the Mobiclip Multicore Encoder tool from the Windows Start menu.  
- Load the queue file manually in the Mobiclip Multicore Encoder on the "Job Queue" tab by clicking the button "Load queue"
- Select the job that appears with by clicking on it, and click the "View job" button to view the job's graph in the "Graph Editor" tab
- Open the "Video Files" filter configuration by double-clicking on it, and then select one of your input video files, and close the filter.
- Verify that all of the filters are green (properly configured); if not, reconfigure the red filters so they turn green.
- Clear the existing job queue by viewing the "Job Queue" tab, and clicking the "Clear queue" button
- Return to the "Graph Editor" tab, and click the "Job Queue" button to add this job to your empty job queue.
- Return to the "Job Queue" tab, and click the "Start queue" button to start processing the job you just added.
- Verify that the job completes successfully and output files are created. Otherwise, you need to view and edit your job again inside the "Graph Editor" tab.
- Save your modifications by clicking on the "Save queue" button on the "Job Queue" tab, and rerun the python script with this new .queue file.